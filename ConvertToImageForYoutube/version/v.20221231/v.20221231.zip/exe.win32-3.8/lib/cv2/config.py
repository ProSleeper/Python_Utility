import os

BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'x86/vc14/bin')
] + BINARIES_PATHS
